package com.example.k_league

class scoreScreenActivity {
}