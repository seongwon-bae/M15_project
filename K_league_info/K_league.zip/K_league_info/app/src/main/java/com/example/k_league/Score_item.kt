package com.example.k_league

// 일단 표시해야하는 목록을 가진 item
class Score_item (
    val position: String, val backNumber: String, val player: String,
            val replacement: String, val goal: String, val assistance: String,
            val shooting: String, val foul:String, val yellowCard: String,
            val redCard: String, val cornerKick: String, val offside: String ) {
}